<?php

if (!defined('QA_VERSION')) { // don't allow this page to be requested directly from browser
	header('Location: ../../../');
	exit;
}

	require_once QA_INCLUDE_DIR . 'db/admin.php';
	require_once QA_INCLUDE_DIR . 'db/maxima.php';
	require_once QA_INCLUDE_DIR . 'db/selects.php';
	require_once QA_INCLUDE_DIR . 'app/options.php';
	require_once QA_INCLUDE_DIR . 'app/admin.php';
	require_once QA_INCLUDE_DIR . 'qa-theme-base.php';
	require_once QA_INCLUDE_DIR . 'qa-app-blobs.php';
	require_once QA_PLUGIN_DIR . 'openid-login/qa-open-page-logins.php';

	class qa_html_theme_layer extends qa_html_theme_base {
		var $plugin_directory;
		var $plugin_url;
		
		public function __construct($template, $content, $rooturl, $request)
		{
			global $qa_layers;
			//$this->pm_adapter_url = '../' . $qa_layers['Private Message Layer']['urltoroot'];
			$this->plugin_directory = $qa_layers['OpenID Admin']['directory'];
			$this->plugin_url = $qa_layers['OpenID Admin']['urltoroot'];
			qa_html_theme_base::qa_html_theme_base($template, $content, $rooturl, $request);
		}
		
		function doctype()
		{
			global $qa_request;
			$adminsection = strtolower(qa_request_part(1));
			$errors = array();
			$securityexpired = false;
			
			if (strtolower(qa_request_part(1)) == 'openid') {
				$this->template = $adminsection;
				$this->admin_navigation($adminsection);
				$this->content['suggest_next']="";
				$this->content['error'] = $securityexpired ? qa_lang_html('admin/form_security_expired') : qa_admin_page_error();
				$this->content['title'] = qa_lang_html('admin/admin_title') . ' - ' . qa_lang('openid/openid_nav');
				$this->content = $this->openid_admin();
			}
			qa_html_theme_base::doctype();
		}
		
		function nav_list($admin_navigation, $class, $level=null)
		{
			if($this->template=='admin') {
				if ($class == 'nav-sub') {
					$admin_navigation['openind'] = array(
						'label' => qa_lang('openid/openid_nav'),
						'url' => qa_path_html('admin/openid'),
					);
				}
				if ( $this->request == 'admin/openid' ) $admin_navigation = array_merge(qa_admin_sub_navigation(), $admin_navigation);
			}
			if(count($admin_navigation) > 1 ) 
				qa_html_theme_base::nav_list($admin_navigation, $class, $level=null);	
		}
		
		function admin_navigation($request)
		{
			$this->content['navigation']['sub'] = qa_admin_sub_navigation();
			$this->content['navigation']['sub']['openid'] = array(
				'label' => qa_lang('openid/openid_nav'),	
				'url' => qa_path_html('admin/openid'),  
				'selected' => ($request == 'openid' ) ? 'selected' : '',
			);
			return 	$this->content['navigation']['sub'];
		}
		
		function openid_admin() {
			$saved = false;
			$allProviders = scandir( '.\qa-plugin\openid-login\Hybrid\Providers' );
			
			if (qa_clicked('general_save_button')) {
				
				// loop through all providers and see which one was enabled
				
				$activeProviders = array();
				foreach($allProviders as $providerFile) {
					if(substr($providerFile,0,1) == '.') {
						continue;
					}

					$provider = str_ireplace('.php', '', $providerFile);
					$key = strtolower($provider);

					$enabled = qa_post_text("{$key}_app_enabled_field");
					$shortcut = qa_post_text("{$key}_app_shortcut_field");
					qa_opt("{$key}_app_enabled", empty($enabled) ? 0 : 1);
					qa_opt("{$key}_app_shortcut", empty($shortcut) ? 0 : 1);
					qa_opt("{$key}_app_id", qa_post_text("{$key}_app_id_field"));
					qa_opt("{$key}_app_secret", qa_post_text("{$key}_app_secret_field"));
					
					if(!empty($enabled)) {
						$activeProviders[] = $provider;
					}
				}
				
				// at the end save a list of all active providers
				file_put_contents( $this->openid_directory . 'providers.php', 
					'<' . '?' . 'php return "' . implode(',', $activeProviders) . '" ?' . '>'
				);
				
				// also save the other configurations
				$hidecss = qa_post_text('open_login_css');
				qa_opt('open_login_css', empty($hidecss) ? 0 : 1);
				
				$zocial = qa_post_text('open_login_zocial');
				qa_opt('open_login_zocial', empty($zocial) ? 0 : 1);
				
				$nologin = qa_post_text('open_login_hideform');
				qa_opt('open_login_hideform', empty($nologin) ? 0 : 1);
				
				$remember = qa_post_text('open_login_remember');
				qa_opt('open_login_remember', empty($remember) ? 0 : 1);
				$saved=true;
			}
			
			$this->content['form'] = array(
				'ok' => $saved ? 'Open Login preferences saved' : null,
				'style' => 'tall',
				
				'fields' => array(
					array(
						'type' => 'checkbox',
						'label' => 'Don\'t inline CSS. I included the styles in my theme\'s CSS file',
						'value' => qa_opt('open_login_css') ? true : false,
						'tags' => 'NAME="open_login_css"',
					),
					
					array(
						'type' => 'checkbox',
						'label' => 'Use <a href="http://zocial.smcllns.com/">Zocial buttons</a> (works out-of-the-box with inlined CSS; if "Don\'t inline CSS" checkbox is selected, the custom theme must be manually modified to import <i>zocial.css</i> file)',
						'value' => qa_opt('open_login_zocial') ? true : false,
						'tags' => 'NAME="open_login_zocial"',
					),
					array(
						'type' => 'checkbox',
						'label' => 'Hide regular login/register forms and keep only external login buttons (might require theme changes)',
						'value' => qa_opt('open_login_hideform') ? true : false,
						'tags' => 'NAME="open_login_hideform"',
					),
					array(
						'type' => 'checkbox',
						'label' => 'Keep users logged in when they connect through external login providers (this will log users in automatically when they return to the site, even if they close their browsers)',
						'value' => qa_opt('open_login_remember') ? true : false,
						'tags' => 'NAME="open_login_remember"',
					),
					array(
						'type' => 'static',
						'label' => '<br /><strong>AVAILABLE LOGIN PROVIDERS</strong>',
					),
				),
				
				'buttons' => array(
					array(
						'label' => 'Save Changes',
						'tags' => 'NAME="general_save_button"',
					),
				),
			);
			$i = 1;
			foreach($allProviders as $providerFile) {
				if(substr($providerFile,0,1) == '.' || $providerFile == 'OpenID.php') {
					continue;
				}
				
				$provider = str_ireplace('.php', '', $providerFile);
				$key = strtolower($provider);
				
				$this->content['form']['fields'][] = array(
					'type' => 'static',
					'label' => '<strong>' . $i . '. '. $provider . ' Login</strong>',
				);
				
				$this->content['form']['fields'][] = array(
					'type' => 'checkbox',
					'label' => 'Enable ' . $provider,
					'value' => qa_opt("{$key}_app_enabled") ? true : false,
					'tags' => "NAME=\"{$key}_app_enabled_field\"",
				);
				
				$this->content['form']['fields'][] = array(
					'type' => 'checkbox',
					'label' => 'Show ' . $provider . ' button in the header',
					'value' => qa_opt("{$key}_app_shortcut") ? true : false,
					'tags' => "NAME=\"{$key}_app_shortcut_field\"",
				);
				
				if($provider == 'Yahoo') {
					$this->content['form']['fields'][] = array(
						'type' => 'static',
						'label' => 'By default, <strong>' . $provider . '</strong> uses OpenID and does not need any keys, so these fields should ' .
									'be left blank. However, if you replaced the provider file with the one that uses OAuth, and not OpenID, you ' .
									'need to provide the app keys.',
					);
					
				} else {					
					
					$this->content['form']['fields'][] = array(
						'label' => $provider . ' App ID:',
						'value' => qa_html(qa_opt("{$key}_app_id")),
						'tags' => "NAME=\"{$key}_app_id_field\"",
					);

					$this->content['form']['fields'][] = array(
						'label' => $provider . ' App Secret:',
						'value' => qa_html(qa_opt("{$key}_app_secret")),
						'tags' => "NAME=\"{$key}_app_secret_field\"",
					);
									
				}
				
				$this->content['form']['fields'][] = array(
					'type' => 'static',
					'label' => 'Callback URL/Redirect URL (to use when registering your application with ' . $provider . '): <br /><strong>' . 
								qa_opt('site_url') . '?hauth.done=' . $provider . '</strong>',
				);
				
				$this->content['form']['fields'][] = array(
					'type' => 'static',
					'label' => '&nbsp;',
				);
				$i++;
			}
			
			return $this->content;
		}
	}

/*
	Omit PHP closing tag to help avoid accidental output
*/
